export default class Console {
  static log (...args) {
    console.log(...args); // eslint-disable-line no-console
  }
}
