
export default
{
  assets: {},
  generator: {}
};
