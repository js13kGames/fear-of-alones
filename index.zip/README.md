# Plumber Wars

### Description
Game

##### pol
Gra w której jesteśmy hydraulikiem w świecie który tonie i chcemy [coś] uratować księżniczę, ocalić ją od zatopienia. Do dyspozcji mamy swój traktor do przewożenia rur, różne rury, różne bazy, w których możemy naładować traktor lub wyprodukować nowe rury, lub zbudować nowy traktor.

Przepomowywujemy wodę zalewając część wyspy, ale osłaniając przejście do kolejnych wysp


#### Build
* npm install
* npm run build

#### Dev
* npm install
* npm run dev

### TODO
* Make it works
* Draw controls
* Dialog class

### IDEA



// get inputs from input and controls and connect with actions in game
//
// bind camera and player
