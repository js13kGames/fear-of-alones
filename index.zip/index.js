import Game from './modules/Game.js';

window.game = new Game();
